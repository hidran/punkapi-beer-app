<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 

        <h2 class="font-semibold text-xl text-gray-800 leading-tight">

            <?php echo e(__('Beers')); ?> :
            <?php if(session()->has('token')): ?>

                Your API TOKEN: <?php echo e(session('token')); ?>

            <?php endif; ?>
        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 bg-white border-b border-gray-200">
                    <h1>Beers</h1>
                    <table>
                        <thead>
                        <tr>
                            <th>id</th>
                            <th>name</th>
                            <th>image</th>
                          
                        </tr>
                        </thead>
                        <tbody id="beers">

                        <?php $__currentLoopData = $beers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $beer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <tr>
                                <td><?php echo e($beer['id']); ?></td>
                                <td><?php echo e($beer['name']); ?></td>
                                <td><img loading="lazy" style="height: 120px" src="<?php echo e($beer['image_url']); ?>"></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                        <tfoot>
                        <tr>
                            <td colspan="3"> <?php echo e($beers->links()); ?></td>
                        </tr>
                        </tfoot>
                    </table>


                </div>

            </div>
        </div>
    </div>
    <script>
        const token = '<?php echo e(session('token')); ?>' || localStorage.getItem('token');
        if (token && !localStorage.getItem('token')) {
            localStorage.setItem('token', token);
        }

    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>

<?php /**PATH /var/www/html/resources/views/beers.blade.php ENDPATH**/ ?>